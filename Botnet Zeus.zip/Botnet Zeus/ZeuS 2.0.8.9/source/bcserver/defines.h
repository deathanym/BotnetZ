#pragma once

#define CWA(dll, api)        ::api
#define MEM_PERSONAL_HEAP    0
#define MEM_ALLOC_SAFE_BYTES 1

#include "..\common\config.h"
#include "..\common\defines.h"
